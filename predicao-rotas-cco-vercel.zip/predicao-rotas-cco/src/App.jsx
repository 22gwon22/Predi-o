import React, { useEffect, useMemo, useState } from "react";
import * as XLSX from "xlsx";

const exemploEscala = `DATA;PLACA;REBOQUE;ROTA;MOTORISTA;TROCA_DE_TURNO;SAIDA_PROGRAMADA;RETORNO_PREV;TEMPO;NECESSIDADE_MANUTEN;OBSERVACAO_ESCALA
20/05/2026;SDZ9J31;*** - ****;PERDILANDIA 01D;ALISSONELES;***** - *****;08:00:00;17:00:00;12:00:00;BAIXO;
20/05/2026;SDX2H31;*** - ****;PALMA DE OURO 01D;DOUGLAS;WILLIAN;04:00:00;20:00:00;17:00:00;BAIXO;
20/05/2026;AFRG9G30;*** - ****;PA RESERVA 01D;FLAVIO TEIXEIRA;***** - *****;04:00:00;20:00:00;17:00:00;BAIXO;
20/05/2026;TTA2F32;BAM0932;CAPINOPOLIS 01R;RELSON;DENILSON;07:00:00;22:00:00;15:00:00;BAIXO;
20/05/2026;RHF7H26;PVA9G37;MONTE ALEGRE 02R;ANDERSON;***** - *****;06:00:00;22:00:00;15:00:00;BAIXO;`;

const exemploOcorrencias = `DATA;ROTA;PLACA;SAIDA_REAL;FIM_REAL;MOTIVO;OBSERVACAO;STATUS_ROTA;KM_PREVISTO;KM_REALIZADO
19/05/2026;UNIÃO DE MINAS 02D;AFR9G30;04:09:00;;; ;RODANDO;;
19/05/2026;SANTA VITÓRIA 02D;SDX2H31;;;Logística;Caminhão está na descarga - aguardando retorno da filial;ATRASO;;
19/05/2026;CAPINOPOLIS 02D;TTA2F32;07:43:00;;; ;ATRASO;;`;

const exemploDePara = `APELIDO;NOME_CORRETO
ALISSONELES;ALISSONELES DE MOURA PRIMO
WILLIAN;WILLIAN BATISTA DA SILVA
ANDERSON;ANDERSON CLEITON DE LIMA
DOUGLAS;DOUGLAS DOS SANTOS NOGUEIRA
RELSON;RELSON CARLOS ALVES SIQUEIRA
FLAVIO TEIXEIRA;FLAVIO LUIZ TEIXEIRA
DENILSON;DENILSON
MARCOS MARTINS;MARCOS MARTINS`;

const exemploExcecoes = `MOTORISTA;MOTIVO
ANDERSON;Agregado`;

const exemploEquipamentos = `PLACA;STATUS;OBSERVACAO
AFRG9G30;PARADO;
SDX2H31;PARADO;
TTO0I42;MANUTENÇÃO;`;

const exemploParametros = `PARAMETRO;VALOR;DESCRICAO
DATA_HOJE;19/05/2026;Dia das ocorrências usadas como base
DATA_AMANHA;20/05/2026;Dia calculado
INTERJORNADA_MINIMA_HORAS;11;Horas mínimas de descanso
DURACAO_PADRAO_HORAS;12;Duração usada quando não houver TEMPO
MARGEM_ALERTA_HORAS;1;Margem de atenção acima da interjornada`;

function norm(v) {
  return String(v ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().trim();
}
function key(v) {
  return norm(v).replace(/[^A-Z0-9]+/g, "_").replace(/^_+|_+$/g, "");
}
function placa(v) {
  return norm(v).replace(/[^A-Z0-9]/g, "");
}
function nomeNorm(v) {
  return norm(String(v ?? "").replace(/^\s*\(AG\)\s*/i, "")).replace(/[^A-Z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
}
function parseCSV(txt) {
  const linhas = String(txt || "").split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (!linhas.length) return [];
  const headerIndex = linhas.findIndex((l) => {
    const n = norm(l);
    return n.includes("DATA") && (n.includes("ROTA") || n.includes("PARAMETRO") || n.includes("PLACA") || n.includes("APELIDO") || n.includes("MOTORISTA"));
  });
  const start = headerIndex >= 0 ? headerIndex : 0;
  const headers = linhas[start].split(";").map(key);
  return linhas.slice(start + 1).map((linha) => {
    const cols = linha.split(";");
    const obj = {};
    headers.forEach((h, i) => (obj[h] = (cols[i] ?? "").trim()));
    return obj;
  });
}
function get(row, nomes) {
  for (const n of nomes) {
    const v = row[key(n)];
    if (v !== undefined && v !== null && String(v).trim() !== "") return String(v).trim();
  }
  return "";
}
function minHora(h) {
  if (!h || String(h).includes("--") || String(h).trim() === "-") return null;
  const txt = String(h).trim().replace(/h/gi, ":");
  const p = txt.split(":").map(Number);
  if (p.length < 2 || Number.isNaN(p[0]) || Number.isNaN(p[1])) return null;
  return p[0] * 60 + p[1];
}
function tempoParaMin(v) {
  const m = minHora(v);
  if (m !== null) return m;
  const n = Number(String(v || "").replace(",", "."));
  return Number.isNaN(n) ? null : n * 60;
}
function dataBR(d) {
  const p = String(d || "").trim().split("/").map(Number);
  if (p.length !== 3 || p.some(Number.isNaN)) return null;
  return new Date(p[2], p[1] - 1, p[0], 0, 0, 0, 0);
}
function dataHoraMin(d, h) {
  const base = dataBR(d);
  const m = minHora(h);
  if (!base || m === null) return null;
  return Math.floor(base.getTime() / 60000) + m;
}
function dur(min) {
  if (min === null || min === undefined || Number.isNaN(min)) return "sem dados";
  const s = min < 0 ? "-" : "";
  const a = Math.abs(Math.round(min));
  return `${s}${String(Math.floor(a / 60)).padStart(2, "0")}h${String(a % 60).padStart(2, "0")}`;
}
function hora(abs) {
  if (abs === null || abs === undefined || Number.isNaN(abs)) return "estimado";
  const m = ((Math.round(abs) % 1440) + 1440) % 1440;
  return `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
}
function rotaBase(rota) {
  return norm(rota).replace(/\b0?1[DR]?\b|\b0?2[DR]?\b/g, "").replace(/\s+/g, " ").trim();
}
function mapaDePara(txt) {
  const m = new Map();
  parseCSV(txt).forEach((r) => {
    const de = get(r, ["APELIDO", "DE", "MOTORISTA"]);
    const para = get(r, ["NOME_CORRETO", "PARA", "NOME COMPLETO"]);
    if (de && para) m.set(nomeNorm(de), para);
  });
  return m;
}
function nomeCorreto(n, mapa) {
  const limpo = String(n || "").replace(/^\s*\(AG\)\s*/i, "").trim();
  if (!limpo || /\*{2,}/.test(limpo)) return "";
  return mapa.get(nomeNorm(limpo)) || limpo;
}
function nomesDaEscala(motorista, troca, mapa) {
  const base = String(motorista || "").split(/\||,|\/| E /i).map((n) => nomeCorreto(n, mapa)).filter(Boolean);
  const trocaOk = troca && !/\*{2,}/.test(troca) && norm(troca) !== "TROCA DE TURNO";
  const extra = trocaOk ? String(troca).split(/\||,|\/| E /i).map((n) => nomeCorreto(n, mapa)).filter(Boolean) : [];
  const final = [...base];
  extra.forEach((n) => {
    if (!final.some((x) => nomeNorm(x) === nomeNorm(n))) final.push(n);
  });
  return final;
}
function motoristas(nomes) {
  return nomes.map((nome, i) => ({ nome, norm: nomeNorm(nome), indice: i, total: nomes.length, papel: nomes.length === 1 ? "Jornada completa" : i === 0 ? "1º turno" : i === 1 ? "2º turno" : `${i + 1}º turno` }));
}
function compat(a, b) {
  const na = nomeNorm(a), nb = nomeNorm(b);
  if (!na || !nb) return false;
  if (na === nb) return true;
  const ta = na.split(" ").filter((t) => t.length >= 4);
  const tb = nb.split(" ").filter((t) => t.length >= 4);
  const iguais = ta.filter((t) => tb.includes(t));
  return iguais.length >= 2 || (ta.length === 1 && iguais.length === 1) || (tb.length === 1 && iguais.length === 1);
}
function excecoesInterjornada(txt, mapa) {
  const out = new Map();
  parseCSV(txt).forEach((r) => {
    const n = get(r, ["MOTORISTA", "NOME", "APELIDO"]);
    const motivo = get(r, ["MOTIVO", "OBSERVACAO"]) || "Desconsiderado";
    if (!n) return;
    out.set(nomeNorm(n), motivo);
    out.set(nomeNorm(nomeCorreto(n, mapa)), motivo);
  });
  return out;
}
function lerEscala(txt, mapa, durPadrao) {
  return parseCSV(txt).map((r) => {
    const data = get(r, ["DATA"]);
    const rota = get(r, ["ROTA"]);
    const inicio = get(r, ["SAIDA_PROGRAMADA", "SAÍDA PROGRAMADA", "SAIDA_ROTEIRIZADA", "INICIO"]);
    const tempo = tempoParaMin(get(r, ["TEMPO", "DURACAO", "DURAÇÃO"]));
    const retorno = get(r, ["RETORNO_PREV", "RETORNO_PREV.", "RETORNO PREVISTO"]);
    const inicioAbs = dataHoraMin(data, inicio);
    const retornoAbs = dataHoraMin(data, retorno);
    let fimAbs = null;
    if (inicioAbs !== null && tempo !== null) fimAbs = inicioAbs + tempo;
    else if (inicioAbs !== null && retornoAbs !== null) fimAbs = retornoAbs <= inicioAbs ? retornoAbs + 1440 : retornoAbs;
    else if (inicioAbs !== null) fimAbs = inicioAbs + durPadrao * 60;
    const nomes = nomesDaEscala(get(r, ["MOTORISTA"]), get(r, ["TROCA_DE_TURNO", "TROCA DE TURNO"]), mapa);
    return {
      data,
      rota,
      rotaBase: rotaBase(rota),
      placa: get(r, ["PLACA", "CAMINHAO", "CAMINHÃO"]),
      placaNorm: placa(get(r, ["PLACA", "CAMINHAO", "CAMINHÃO"])),
      reboque: get(r, ["REBOQUE"]),
      reboqueNorm: placa(get(r, ["REBOQUE"])),
      motorista: nomes.join(" | "),
      motoristas: motoristas(nomes),
      trocaOriginal: get(r, ["TROCA_DE_TURNO", "TROCA DE TURNO"]),
      inicio,
      inicioAbs,
      fimAbs,
      retornoPrev: fimAbs ? hora(fimAbs) : "sem previsão",
      tempoRotaMin: inicioAbs !== null && fimAbs !== null ? fimAbs - inicioAbs : null,
      manutencao: get(r, ["NECESSIDADE_MANUTEN", "NECESSIDADE MANUTEN", "MANUTENCAO"]),
      obsEscala: get(r, ["OBSERVACAO_ESCALA", "OBSERVAÇÃO_ESCALA"]),
    };
  }).filter((r) => r.data && r.rota && r.placa);
}
function aplicarOcorrencias(escala, ocorrencias, durPadrao) {
  const oc = parseCSV(ocorrencias).map((r) => ({ data: get(r, ["DATA"]), rotaBase: rotaBase(get(r, ["ROTA"])), placaNorm: placa(get(r, ["PLACA"])), saida: get(r, ["SAIDA_REAL", "SAÍDA_REAL", "SAIDA"]), fim: get(r, ["FIM_REAL", "FIM", "RETORNO", "ENCERRAMENTO"]), motivo: get(r, ["MOTIVO"]), obs: get(r, ["OBSERVACAO", "OBSERVAÇÃO"]), status: get(r, ["STATUS_ROTA", "STATUS"]) }));
  return escala.map((r) => {
    const o = oc.find((x) => (x.placaNorm && x.placaNorm === r.placaNorm) || (x.rotaBase && x.rotaBase === r.rotaBase));
    if (!o) return { ...r, saidaReal: r.inicio, saidaAbs: r.inicioAbs, fimHojeAbs: r.fimAbs, motivo: "", observacao: "", statusRota: "", fimEstimado: true, desvioMin: null };
    const saidaAbs = dataHoraMin(r.data, o.saida || r.inicio);
    let fimAbs = dataHoraMin(r.data, o.fim);
    if (fimAbs !== null && saidaAbs !== null && fimAbs <= saidaAbs) fimAbs += 1440;
    if (fimAbs === null && saidaAbs !== null) fimAbs = saidaAbs + (r.tempoRotaMin || durPadrao * 60);
    return { ...r, saidaReal: o.saida || r.inicio, saidaAbs: saidaAbs ?? r.inicioAbs, fimHojeAbs: fimAbs ?? r.fimAbs, motivo: o.motivo, observacao: o.obs, statusRota: o.status, fimEstimado: !o.fim, desvioMin: minHora(o.saida) !== null && minHora(r.inicio) !== null ? minHora(o.saida) - minHora(r.inicio) : null };
  });
}
function turno(row, mot) {
  const inicio = row.saidaAbs ?? row.inicioAbs;
  const fim = row.fimHojeAbs ?? row.fimAbs;
  if (inicio === null || fim === null) return null;
  if (mot.total <= 1) return { inicioAbs: inicio, fimAbs: fim };
  const parte = (fim - inicio) / mot.total;
  return { inicioAbs: inicio + Math.round(parte * mot.indice), fimAbs: mot.indice === mot.total - 1 ? fim : inicio + Math.round(parte * (mot.indice + 1)) };
}
function extrairPlacas(txt) {
  return [...new Set((norm(txt).match(/[A-Z]{3}\d[A-Z0-9]\d{2}/g) || []).map(placa))];
}
function risco(score) {
  if (score >= 60) return "Alto";
  if (score >= 35) return "Médio";
  return "Baixo";
}
function parseParametros(txt) {
  const p = {};
  parseCSV(txt).forEach((r) => {
    const k = key(get(r, ["PARAMETRO", "CHAVE"]));
    const v = get(r, ["VALOR"]);
    if (k) p[k] = v;
  });
  return p;
}
function gerarPredicao({ escalaTxt, ocorrTxt, deParaTxt, excecoesTxt, equipamentosTxt, parametrosTxt, historico }) {
  const p = parseParametros(parametrosTxt);
  const dataHoje = p.DATA_HOJE || "19/05/2026";
  const dataAmanha = p.DATA_AMANHA || "20/05/2026";
  const durPadrao = Number(p.DURACAO_PADRAO_HORAS || 12);
  const interMin = Number(p.INTERJORNADA_MINIMA_HORAS || 11) * 60;
  const margem = Number(p.MARGEM_ALERTA_HORAS || 1) * 60;
  const mapa = mapaDePara(deParaTxt);
  const ignorar = excecoesInterjornada(excecoesTxt, mapa);
  const escala = lerEscala(escalaTxt, mapa, durPadrao);
  const hojeEscala = escala.filter((r) => r.data === dataHoje);
  const amanha = escala.filter((r) => r.data === dataAmanha);
  const hoje = aplicarOcorrencias(hojeEscala, ocorrTxt, durPadrao);
  const bloqueados = new Map();
  parseCSV(equipamentosTxt).forEach((e) => {
    const p = placa(get(e, ["PLACA"]));
    if (p) bloqueados.set(p, get(e, ["STATUS", "SITUACAO"]) || "PARADO");
  });

  const porPlaca = new Map();
  const porRota = new Map();
  hoje.forEach((r) => {
    const txt = norm(`${r.motivo} ${r.observacao} ${r.statusRota}`);
    const placas = new Set([r.placaNorm, ...extrairPlacas(txt)]);
    placas.forEach((p) => {
      if (!p) return;
      const arr = porPlaca.get(p) || [];
      if (/PROBLEMA|CARDAN|ROLAMENTO|MANUTENCAO|DESCARGA|AGUARDANDO|PARADO|QUEBROU|OFICINA|LOGISTICA/.test(txt)) arr.push({ peso: 45, msg: `Ocorrência operacional ligada ao equipamento ${p}: ${r.motivo || r.observacao || r.statusRota}` });
      if (r.desvioMin !== null && r.desvioMin > 15) arr.push({ peso: 15, msg: `Saiu ${r.desvioMin} min após o previsto em ${r.rota}` });
      if (r.desvioMin !== null && r.desvioMin < -30) arr.push({ peso: 8, msg: `Saiu ${Math.abs(r.desvioMin)} min antes do previsto em ${r.rota}` });
      porPlaca.set(p, arr);
    });
    const rr = porRota.get(r.rotaBase) || [];
    if (/DIVERGENCIA|HORARIO DE SAIDA|ROTEIRIZACAO/.test(txt)) rr.push({ peso: 30, msg: "Divergência de roteirização/horário identificada na rota-base" });
    if (/MAO DE OBRA|MOTORISTA|ADIANTAMENTO/.test(txt)) rr.push({ peso: 18, msg: "Ocorrência de mão de obra/aderência de motorista na rota-base" });
    porRota.set(r.rotaBase, rr);
  });

  return amanha.map((r) => {
    let score = 5;
    const motivos = [];
    const acoes = [];
    const interjornadas = [];

    [r.placaNorm, r.reboqueNorm].filter(Boolean).forEach((p) => {
      if (bloqueados.has(p)) {
        score += 50;
        motivos.push(`${p} está listado como ${bloqueados.get(p)}`);
        acoes.push(`Confirmar liberação/substituição do equipamento ${p} antes da escala`);
      }
      (porPlaca.get(p) || []).forEach((pb) => { score += pb.peso; motivos.push(pb.msg); });
    });

    (porRota.get(r.rotaBase) || []).forEach((pb) => { score += pb.peso; motivos.push(pb.msg); });

    const histRota = historico.filter((h) => rotaBase(h.rota) === r.rotaBase).slice(-5);
    const histPlaca = historico.filter((h) => placa(h.placa) === r.placaNorm).slice(-5);
    const reincidente = [...histRota, ...histPlaca].some((h) => ["Alto", "Médio"].includes(h.nivel));
    if (reincidente) {
      score += 12;
      motivos.push("Histórico recente possui risco médio/alto para a mesma rota ou equipamento.");
      acoes.push("Comparar com histórico antes de liberar a saída e validar se a causa anterior foi tratada.");
    }

    r.motoristas.forEach((ma) => {
      if (ignorar.has(ma.norm)) {
        interjornadas.push({ motorista: ma.nome, status: "Desconsiderado", descanso: null, deficit: 0, hoje: ignorar.get(ma.norm), amanha: `${r.rota} • ${ma.papel}` });
        motivos.push(`Interjornada desconsiderada para ${ma.nome}: ${ignorar.get(ma.norm)}.`);
        return;
      }
      const ta = turno(r, ma);
      if (!ta) return;
      const candidatos = hoje.flatMap((j) => j.motoristas.filter((mh) => compat(mh.norm, ma.norm)).map((mh) => ({ j, mh, th: turno(j, mh) })));
      const ultima = candidatos.filter((c) => c.th && c.th.fimAbs <= ta.inicioAbs).sort((a, b) => b.th.fimAbs - a.th.fimAbs)[0];
      if (!ultima) return;
      const descanso = ta.inicioAbs - ultima.th.fimAbs;
      const deficit = interMin - descanso;
      const status = deficit > 0 ? "Irregular" : descanso <= interMin + margem ? "Atenção" : "OK";
      interjornadas.push({ motorista: ma.nome, status, descanso, deficit: Math.max(deficit, 0), hoje: `${ultima.j.rota} • ${ultima.mh.papel} • fim ${hora(ultima.th.fimAbs)}`, amanha: `${r.rota} • ${ma.papel} • início ${hora(ta.inicioAbs)}` });
      if (deficit > 0) {
        score += 55;
        motivos.push(`Interjornada crítica: ${ma.nome} terá apenas ${dur(descanso)} de descanso. Déficit de ${dur(deficit)}.`);
        acoes.push(`Trocar motorista ou ajustar horário para cumprir ${interMin / 60}h de interjornada`);
      } else if (descanso <= interMin + margem) {
        score += 25;
        motivos.push(`Interjornada em atenção: ${ma.nome} terá ${dur(descanso)} de descanso.`);
        acoes.push(`Confirmar horário real de fim/início do turno de ${ma.nome}`);
      }
    });

    if (r.inicioAbs !== null && minHora(r.inicio) <= 4 * 60) {
      score += 8;
      motivos.push("Saída muito cedo; pouca janela para corrigir falha antes da rota.");
    }
    if (r.tempoRotaMin >= 18 * 60) {
      score += 10;
      motivos.push(`Rota longa pela escala: tempo previsto de ${dur(r.tempoRotaMin)}.`);
    }
    if (!motivos.length) motivos.push("Sem impacto direto identificado com os dados importados.");
    if (score >= 60) {
      acoes.push("Acionar operação/logística ainda hoje e deixar plano reserva definido.");
    } else if (score >= 35) {
      acoes.push("Validar disponibilidade do equipamento e alinhamento do motorista antes do horário de saída.");
    } else {
      acoes.push("Manter monitoramento normal no controle de saída.");
    }
    const nivel = risco(Math.min(score, 100));
    return { ...r, score: Math.min(score, 100), nivel, motivos: [...new Set(motivos)], acoes: [...new Set(acoes)], interjornadas };
  }).sort((a, b) => b.score - a.score);
}

function sheetToCsv(sheet) {
  const arr = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: false, defval: "" });
  return arr.filter((r) => r.some((c) => String(c).trim() !== "")).map((r) => r.map((c) => String(c ?? "").replace(/\r?\n/g, " ")).join(";")).join("\n");
}
function acharAba(wb, nomes) {
  const targets = nomes.map(key);
  const name = wb.SheetNames.find((n) => targets.includes(key(n)));
  return name ? wb.Sheets[name] : null;
}
function baixarTexto(nome, conteudo, tipo = "text/csv;charset=utf-8") {
  const blob = new Blob([conteudo], { type: tipo });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = nome;
  a.click();
  URL.revokeObjectURL(url);
}

export default function App() {
  const [escalaTxt, setEscalaTxt] = useState(exemploEscala);
  const [ocorrTxt, setOcorrTxt] = useState(exemploOcorrencias);
  const [deParaTxt, setDeParaTxt] = useState(exemploDePara);
  const [excecoesTxt, setExcecoesTxt] = useState(exemploExcecoes);
  const [equipTxt, setEquipTxt] = useState(exemploEquipamentos);
  const [paramTxt, setParamTxt] = useState(exemploParametros);
  const [historico, setHistorico] = useState([]);
  const [tab, setTab] = useState("predicao");
  const [msg, setMsg] = useState("");

  useEffect(() => {
    try {
      const salvo = JSON.parse(localStorage.getItem("historico_predicao_rotas_cco") || "[]");
      if (Array.isArray(salvo)) setHistorico(salvo);
    } catch {
      // ignora histórico inválido
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("historico_predicao_rotas_cco", JSON.stringify(historico));
  }, [historico]);

  const predicao = useMemo(() => gerarPredicao({ escalaTxt, ocorrTxt, deParaTxt, excecoesTxt, equipamentosTxt: equipTxt, parametrosTxt: paramTxt, historico }), [escalaTxt, ocorrTxt, deParaTxt, excecoesTxt, equipTxt, paramTxt, historico]);
  const resumo = {
    alto: predicao.filter((p) => p.nivel === "Alto").length,
    medio: predicao.filter((p) => p.nivel === "Médio").length,
    baixo: predicao.filter((p) => p.nivel === "Baixo").length,
    inter: predicao.filter((p) => p.interjornadas?.some((i) => i.status !== "OK" && i.status !== "Desconsiderado")).length,
  };
  const params = parseParametros(paramTxt);

  function importarExcel(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const wb = XLSX.read(evt.target.result, { type: "array", cellDates: false });
        const escala = acharAba(wb, ["ESCALA_DIA_SEGUINTE", "ESCALA_OFICIAL", "ESCALA"]);
        const ocorr = acharAba(wb, ["OCORRENCIAS_DIA_ATUAL", "OCORRÊNCIAS_DIA_ATUAL", "OCORRENCIAS", "OCORRÊNCIAS"]);
        const depara = acharAba(wb, ["DE_PARA_MOTORISTAS", "DE_PARA", "MOTORISTAS"]);
        const exc = acharAba(wb, ["EXCECOES_INTERJORNADA", "EXCEÇÕES_INTERJORNADA", "SEM_INTERJORNADA"]);
        const equip = acharAba(wb, ["EQUIPAMENTOS", "FROTA"]);
        const param = acharAba(wb, ["PARAMETROS", "PARÂMETROS"]);
        const hist = acharAba(wb, ["HISTORICO_ROTAS", "HISTÓRICO_ROTAS", "HISTORICO"]);
        if (escala) setEscalaTxt(sheetToCsv(escala));
        if (ocorr) setOcorrTxt(sheetToCsv(ocorr));
        if (depara) setDeParaTxt(sheetToCsv(depara));
        if (exc) setExcecoesTxt(sheetToCsv(exc));
        if (equip) setEquipTxt(sheetToCsv(equip));
        if (param) setParamTxt(sheetToCsv(param));
        if (hist) {
          const linhas = parseCSV(sheetToCsv(hist)).map((r) => ({
            data: get(r, ["DATA"]), rota: get(r, ["ROTA"]), placa: get(r, ["PLACA"]), motorista: get(r, ["MOTORISTA"]), nivel: get(r, ["NIVEL_RISCO"]), score: Number(get(r, ["SCORE"]) || 0), motivos: get(r, ["OBSERVACAO", "MOTIVO"]), acoes: get(r, ["ACOES_TOMADAS"]), salvoEm: new Date().toISOString()
          })).filter((r) => r.rota);
          setHistorico((h) => [...h, ...linhas]);
        }
        setMsg(`Arquivo importado: ${file.name}`);
        setTab("predicao");
      } catch (err) {
        setMsg(`Erro ao importar: ${err.message}`);
      }
    };
    reader.readAsArrayBuffer(file);
  }

  function salvarHistorico() {
    const novos = predicao.map((p) => ({
      data: p.data,
      rota: p.rota,
      placa: p.placa,
      reboque: p.reboque,
      motorista: p.motorista,
      inicio: p.inicio,
      retornoPrev: p.retornoPrev,
      tempo: dur(p.tempoRotaMin),
      nivel: p.nivel,
      score: p.score,
      motivos: p.motivos.join(" | "),
      acoes: p.acoes.join(" | "),
      salvoEm: new Date().toISOString(),
    }));
    setHistorico((h) => [...h, ...novos]);
    setMsg(`${novos.length} rotas salvas no histórico local.`);
  }

  function exportarHistorico() {
    const header = ["DATA", "ROTA", "PLACA", "REBOQUE", "MOTORISTA", "INICIO", "RETORNO_PREV", "TEMPO", "NIVEL_RISCO", "SCORE", "MOTIVOS", "ACOES", "SALVO_EM"];
    const linhas = historico.map((h) => [h.data, h.rota, h.placa, h.reboque || "", h.motorista, h.inicio || "", h.retornoPrev || "", h.tempo || "", h.nivel, h.score, h.motivos, h.acoes, h.salvoEm].join(";"));
    baixarTexto("historico_predicao_rotas.csv", [header.join(";"), ...linhas].join("\n"));
  }

  function baixarModelo() {
    const wb = XLSX.utils.book_new();
    const add = (name, csv) => XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(csv.split(/\r?\n/).map((l) => l.split(";"))), name);
    add("ESCALA_DIA_SEGUINTE", exemploEscala);
    add("OCORRENCIAS_DIA_ATUAL", exemploOcorrencias);
    add("DE_PARA_MOTORISTAS", exemploDePara);
    add("EXCECOES_INTERJORNADA", exemploExcecoes);
    add("EQUIPAMENTOS", exemploEquipamentos);
    add("PARAMETROS", exemploParametros);
    add("HISTORICO_ROTAS", "DATA;ROTA;PLACA;REBOQUE;MOTORISTA;SAIDA_PROGRAMADA;SAIDA_REAL;FIM_PREVISTO;FIM_REAL;TEMPO_PREVISTO;ATRASO_MIN;MOTIVO;OBSERVACAO;NIVEL_RISCO;SCORE;ACOES_TOMADAS");
    XLSX.writeFile(wb, "PADRAO_IMPORTACAO_PREDICAO_ROTAS_CCO.xlsx");
  }

  const cor = { Alto: "bg-red-100 text-red-800 border-red-200", Médio: "bg-amber-100 text-amber-800 border-amber-200", Baixo: "bg-emerald-100 text-emerald-800 border-emerald-200" };
  const bolinha = { Alto: "bg-red-500", Médio: "bg-amber-500", Baixo: "bg-emerald-500", OK: "bg-emerald-500", Atenção: "bg-amber-500", Irregular: "bg-red-500", Desconsiderado: "bg-slate-400" };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-5">
      <div className="mx-auto max-w-7xl space-y-5">
        <header className="rounded-2xl border border-slate-800 bg-slate-900 p-5 shadow-xl">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.25em] text-cyan-300">CCO • Predição de rotas</p>
              <h1 className="mt-2 text-3xl font-bold">Predição do dia seguinte</h1>
              <p className="mt-2 text-sm text-slate-400">Importe um Excel padronizado, calcule o risco de amanhã e salve o histórico para comparar recorrência de rota, placa e interjornada.</p>
              <p className="mt-1 text-xs text-slate-500">Base: hoje {params.DATA_HOJE || "-"} → amanhã {params.DATA_AMANHA || "-"}</p>
            </div>
            <div className="grid grid-cols-4 gap-2 text-center">
              <div className="rounded-xl border border-red-900 bg-red-950/40 p-3"><div className="text-2xl font-bold text-red-300">{resumo.alto}</div><div className="text-xs text-red-200">Alto</div></div>
              <div className="rounded-xl border border-amber-900 bg-amber-950/40 p-3"><div className="text-2xl font-bold text-amber-300">{resumo.medio}</div><div className="text-xs text-amber-200">Médio</div></div>
              <div className="rounded-xl border border-emerald-900 bg-emerald-950/40 p-3"><div className="text-2xl font-bold text-emerald-300">{resumo.baixo}</div><div className="text-xs text-emerald-200">Baixo</div></div>
              <div className="rounded-xl border border-cyan-900 bg-cyan-950/40 p-3"><div className="text-2xl font-bold text-cyan-300">{resumo.inter}</div><div className="text-xs text-cyan-200">Interj.</div></div>
            </div>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <label className="cursor-pointer rounded-xl bg-cyan-400 px-4 py-2 text-sm font-bold text-slate-950 hover:bg-cyan-300">
              Importar Excel
              <input type="file" accept=".xlsx,.xls" className="hidden" onChange={importarExcel} />
            </label>
            <button onClick={baixarModelo} className="rounded-xl border border-slate-700 px-4 py-2 text-sm text-slate-200 hover:bg-slate-800">Baixar modelo</button>
            <button onClick={salvarHistorico} className="rounded-xl border border-slate-700 px-4 py-2 text-sm text-slate-200 hover:bg-slate-800">Salvar predição no histórico</button>
            <button onClick={exportarHistorico} className="rounded-xl border border-slate-700 px-4 py-2 text-sm text-slate-200 hover:bg-slate-800">Exportar histórico</button>
            <button onClick={() => { setHistorico([]); setMsg("Histórico local limpo."); }} className="rounded-xl border border-red-900 px-4 py-2 text-sm text-red-200 hover:bg-red-950/50">Limpar histórico</button>
          </div>
          {msg && <div className="mt-3 rounded-xl border border-cyan-900 bg-cyan-950/30 px-4 py-2 text-sm text-cyan-100">{msg}</div>}
        </header>

        <nav className="flex gap-2 border-b border-slate-800 pb-2">
          {[["predicao", "Predição"], ["dados", "Dados importados"], ["historico", "Histórico"]].map(([id, label]) => <button key={id} onClick={() => setTab(id)} className={`rounded-t-xl px-4 py-2 text-sm font-semibold ${tab === id ? "bg-slate-800 text-cyan-300" : "text-slate-400 hover:bg-slate-900"}`}>{label}</button>)}
        </nav>

        {tab === "predicao" && (
          <section className="rounded-2xl border border-slate-800 bg-slate-900 p-4">
            {predicao.length === 0 ? <div className="p-8 text-center text-slate-400">Nenhuma rota encontrada para DATA_AMANHA. Importe uma escala com a data do próximo dia na aba ESCALA_DIA_SEGUINTE.</div> : <div className="overflow-x-auto">
              <table className="w-full min-w-[1200px] text-left text-sm">
                <thead className="bg-slate-800 text-xs uppercase text-slate-300"><tr><th className="p-3">Risco</th><th className="p-3">Rota</th><th className="p-3">Início</th><th className="p-3">Motorista</th><th className="p-3">Placa</th><th className="p-3">Tempo</th><th className="p-3">Interjornada</th><th className="p-3">Motivos</th><th className="p-3">Ações</th></tr></thead>
                <tbody className="divide-y divide-slate-800">
                  {predicao.map((p, i) => <tr key={`${p.rota}-${i}`} className="align-top hover:bg-slate-800/40">
                    <td className="p-3"><span className={`inline-flex rounded-full border px-3 py-1 text-xs font-bold ${cor[p.nivel]}`}>{p.nivel} • {p.score}</span></td>
                    <td className="p-3 font-semibold text-white">{p.rota}</td>
                    <td className="p-3 text-cyan-200">{p.inicio}</td>
                    <td className="p-3 text-slate-300">{p.motoristas.map((m) => `${m.nome}${m.total > 1 ? ` (${m.papel})` : ""}`).join(" → ")}</td>
                    <td className="p-3 font-mono text-slate-300">{p.placa}{p.reboque && !p.reboque.includes("***") ? ` / ${p.reboque}` : ""}</td>
                    <td className="p-3 text-slate-300">{dur(p.tempoRotaMin)}<br /><span className="text-xs text-slate-500">Ret. {p.retornoPrev}</span></td>
                    <td className="p-3"><div className="space-y-2">{p.interjornadas?.length ? p.interjornadas.map((j, k) => <div key={k} className="rounded-xl border border-slate-800 bg-slate-950 p-2"><div className="flex items-center gap-2"><span className={`h-2 w-2 rounded-full ${bolinha[j.status] || "bg-slate-400"}`} /><b className="text-xs">{j.status}</b></div><div className="mt-1 text-xs text-slate-400">{j.motorista}</div><div className="text-xs text-slate-500">Hoje: {j.hoje}</div><div className="text-xs text-slate-500">Amanhã: {j.amanha}</div><div className="text-xs text-slate-400">Descanso: {dur(j.descanso)}</div>{j.deficit > 0 && <div className="text-xs text-red-300">Déficit: {dur(j.deficit)}</div>}</div>) : <span className="text-xs text-slate-500">Sem vínculo</span>}</div></td>
                    <td className="p-3 text-slate-300"><ul className="list-disc space-y-1 pl-4">{p.motivos.map((m) => <li key={m}>{m}</li>)}</ul></td>
                    <td className="p-3 text-slate-300"><ul className="list-disc space-y-1 pl-4">{p.acoes.map((a) => <li key={a}>{a}</li>)}</ul></td>
                  </tr>)}
                </tbody>
              </table>
            </div>}
          </section>
        )}

        {tab === "dados" && <section className="grid gap-4 lg:grid-cols-2">
          {[["ESCALA_DIA_SEGUINTE", escalaTxt, setEscalaTxt], ["OCORRENCIAS_DIA_ATUAL", ocorrTxt, setOcorrTxt], ["DE_PARA_MOTORISTAS", deParaTxt, setDeParaTxt], ["EXCECOES_INTERJORNADA", excecoesTxt, setExcecoesTxt], ["EQUIPAMENTOS", equipTxt, setEquipTxt], ["PARAMETROS", paramTxt, setParamTxt]].map(([titulo, val, set]) => <div key={titulo} className="rounded-2xl border border-slate-800 bg-slate-900 p-4"><h3 className="mb-2 font-bold">{titulo}</h3><textarea value={val} onChange={(e) => set(e.target.value)} className="h-52 w-full rounded-xl border border-slate-700 bg-slate-950 p-3 font-mono text-xs text-slate-100 outline-none focus:border-cyan-400" /></div>)}
        </section>}

        {tab === "historico" && <section className="rounded-2xl border border-slate-800 bg-slate-900 p-4">
          <h2 className="mb-3 text-xl font-bold">Histórico local</h2>
          <p className="mb-4 text-sm text-slate-400">Esse histórico fica salvo no navegador via localStorage. Para backup, use Exportar histórico.</p>
          <div className="overflow-x-auto"><table className="w-full min-w-[1000px] text-left text-sm"><thead className="bg-slate-800 text-xs uppercase text-slate-300"><tr><th className="p-3">Data</th><th className="p-3">Rota</th><th className="p-3">Placa</th><th className="p-3">Motorista</th><th className="p-3">Risco</th><th className="p-3">Score</th><th className="p-3">Motivos</th></tr></thead><tbody className="divide-y divide-slate-800">{historico.slice().reverse().map((h, i) => <tr key={i}><td className="p-3">{h.data}</td><td className="p-3">{h.rota}</td><td className="p-3 font-mono">{h.placa}</td><td className="p-3">{h.motorista}</td><td className="p-3">{h.nivel}</td><td className="p-3">{h.score}</td><td className="p-3 text-slate-400">{h.motivos}</td></tr>)}</tbody></table></div>
        </section>}
      </div>
    </div>
  );
}
